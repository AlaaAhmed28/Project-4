/* Global Variables */

// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth()+'.'+ d.getDate()+'.'+ d.getFullYear();
// API key  and zip code
const URL= 'https://api.openweathermap.org/data/2.5/forecast?zip=';
let ApiKey='60b97f947a844fd481f942337b5bc692';
 
const Generate = document.getElementById('generate');
Generate.addEventListener('click',action);

function action(){
    const Feelings= document.getElementById('feelings');
    const zipCode= document.getElementById('zip');
}