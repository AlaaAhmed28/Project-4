/* Global Variables */

// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth() + 1 + '.' + d.getDate() + '.' + d.getFullYear();
// API key  and zip code
const URL = 'https://api.openweathermap.org/data/2.5/weather?zip=';
const ApiKey = '&appid=60b97f947a844fd481f942337b5bc692&units=imperial';
const Generate = document.getElementById('generate');


async function action() {
  const Feelings = document.getElementById('feelings').value;
  const zipCode = document.getElementById('zip').value;
  getWeatherData(zipCode).then((data) => {
    postData("/gather", { date: newDate, temp: data.main.temp, content: Feelings })
      .then(() => updateUI())
  })
}
Generate.addEventListener('click', action);

const getWeatherData = async (zipCode) => {
  const response = await fetch(URL + zipCode + ApiKey);
  try {
    const data = await response.json();
    return data
  } catch (error) {
    console.log("error", error);
  }
}

async function postData(url = '', data = {}) {
  const response = await fetch(url, {
    method: 'POST',
    credentials: 'same-origin',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  });
  try {
    const data = await response.json();
    return data;
  } catch (error) {
    // console.log("error",error);
  }
}
const updateUI = async () => {
  const response = await fetch("/add")
  try {
    const allData = await response.json();
    document.getElementById('date').innerHTML = allData.date;
    document.getElementById('temp').innerHTML = allData.temp;
    document.getElementById('content').innerHTML = allData.content;
  }
  catch (error) {

  }
}