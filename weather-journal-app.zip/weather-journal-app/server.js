// Setup empty JS object to act as endpoint for all routes
projectData = {};

// Require Express to run server and routes
const express = require('express');
// Start up an instance of app
const app = express();
/* Middleware*/
//Here we are configuring express to use body-parser as middle-ware.
const bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Cors for cross origin allowance
var cors = require('cors');
app.get('all', cors(), function (req, res) {
    res.json({msg: 'This is CORS-enabled for a Single Route'})
  })
   
  app.listen(80, function () {
    console.log('CORS-enabled web server listening on port 80')
  })
// Initialize the main project folder
app.use(express.static('website'));


// Setup Server
const port = 3080;

const server = app.listen(port, display);

// calling display function
function display() {
    console.log('Server Is Running');
    console.log(`LocalCost : ${port}`);
}
// Initialize all data from a call back function
app.get('/gather', resData);

function resData(req, res) {
    res.send(projectData);
    projectData = {};
}
// Post Route
app.post('/gather', appendData);

function appendData(req, res) {
    console.log(req.body);
    newIngress = {
        date: req.body.date,
        temp: req.body.temp,
        content: req.body.content
    }
    projectData = newIngress;
    res.send(projectData);
}
