window.scrollTo({
  top: 100,
  behavior: 'smooth'
});
//Defining the variables
const sections= Array.from(document.getElementsByTagName('section'));
const navList = document.getElementById("navbar__list");
// Inserting the code of the code in the html
const navBar = function(){
        for(section of sections){
            let navItem = document.createElement("li");
            let sectionName= section.getAttribute("data-nav");
            let sectionID= section.getAttribute('id');
            navItem.innerHTML=`<a class="menu__link" href='#${sectionID}'>${sectionName}</a>`;
            navList.appendChild(navItem); 
          };
        };
     // Displaying the Navigation Bar
     navBar();
   //check if the section is in the viewPort
     function viewPort (element){
         const sectionPosition = element.getBoundingClientRect();
         return (sectionPosition.top>=0);
     }
     const your_active_class =document.querySelector('.your-active-class');
    // create a function to call all the below in the .addEventListener
     function checkForTheActvClass (){
         for (section of sections){
            //if the section is in the viewPort
            if (viewPort(section)){
                //check if it isn't containg your-active-class
                if (!section.classList.contains('your-active-class')){
                     // Then add it ('your-active-class')
                     section.classList.add('your-active-class');
                 }
             }
                else { 
                    //if it is not inside the viewPort then remove it ('your-active-class')
                    section.classList.remove('your-active-class');
             }
         }
     }
     
    // Using the .addEventListener in order to use the scroll action 
     document.addEventListener('scroll',checkForTheActvClass);