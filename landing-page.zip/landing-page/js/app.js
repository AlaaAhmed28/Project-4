
//Defining the variables
const callSections= document.getElementsByTagName('section');
// Calling the ul element form the HTML
const unorderedList = document.getElementsByTagName('ul');
function scrollSec(item, sec){
  item.addEventListener('click', function(e){
        e.preventDefault();
        sec.scrollIntoView({behavior: "smooth"})
  })
}
      // Inserting the code of the code in the html
     const navBar = function(){
        for(section of callSections){
            let listItem = document.createElement("li");
            let text = document.createTextNode(section.dataset.nav);
            let anchor=  document.createElement("a");
            let sectionID= section.getAttribute('id');
            anchor.href=`#${sectionID}`;
            anchor.className = "menu__link";
            anchor.appendChild(text);
            listItem.appendChild(anchor);
            unorderedList[0].appendChild(listItem);
            scrollSec(listItem, section)
          };
          
     };
     // Displaying the Navigation Bar
     navBar();

     function check(section){
      const rect = section.getBoundingClientRect().top;
        console.log(rect.top>=0);
        return rect
       }
     const activeClass = function(){
      for(section of callSections){
        if (check(section) == window.pageXOffset){
          section.classList.add('your-active-class');
        }
        else{
          section.classList.remove('your-active-class');
        }
      }
     };
      
      document.addEventListener('scroll',activeClass);
          

        