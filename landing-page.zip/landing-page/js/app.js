//Defining the variables
const callSections= document.getElementsByTagName('section'),
      callNavElements=document.getElementsByClassName('navbar__list');
      for(section of callSections){
        let navItem = document.createElement("li");
      }
      // Calling the ul element form the HTML
      const unorderedList = document.getElementsByTagName('ul');
      // Inserting the code of the code in the html
     const navBar = function(){
        const htmlCodeToAdd= '<li><a class="menu__link" href="#section1">Section 1</a></li><li><a class="menu__link" href="#section2">Section 2</a></li><li><a class="menu__link" href="#section3">Section 3</a></li> <li><a class="menu__link" href="#section4">Section 4</a></li>';
        //Using the .insertAdjacentHTML()
        unorderedList[0].insertAdjacentHTML('afterbegin', htmlCodeToAdd);
     };
    
     // Displaying the Navigation Bar
     navBar();
   //check if the section is in the viewPort
     function viewPort (element){
         const sectionPosition = element.getBoundingClientRect();
         return (sectionPosition.top>=0);
     }
     const your_active_class =document.querySelector('.your-active-class');
    // create a function to call all the below in the .addEventListener
     function checkForTheActvClass (){
         for (section of callSections){
            //if the section is in the viewPort
            if (viewPort(section)){
                //check if it isn't containg your-active-class
                if (!section.classList.contains('your-active-class')){
                     // Then add it ('your-active-class')
                     section.classList.add('your-active-class');
                 }
             }
                else { 
                    //if it is not inside the viewPort then remove it ('your-active-class')
                    section.classList.remove('your-active-class');
             }
         }
     }
     
    // Using the .addEventListener in order to use the scroll action 
     document.addEventListener('scroll',checkForTheActvClass);
    
