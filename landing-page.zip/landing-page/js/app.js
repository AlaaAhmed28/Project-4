
//Defining the variables
const callSections= document.getElementsByTagName('section');
// Calling the ul element form the HTML
const unorderedList = document.getElementsByTagName('ul');
function scrollSec(item, sec){
  item.addEventListener('click', function(e){
        e.preventDefault();
        sec.scrollIntoView({behavior: "smooth"})
  })
}
      // Inserting the code of the code in the html
     const navBar = function(){
        for(section of callSections){
            let listItem = document.createElement("li");
            let text = document.createTextNode(section.dataset.nav);
            let anchor=  document.createElement("a");
            let sectionID= section.getAttribute('id');
            anchor.href=`#${sectionID}`;
            anchor.className = "menu__link";
            anchor.appendChild(text);
            listItem.appendChild(anchor);
            unorderedList[0].appendChild(listItem);
            scrollSec(listItem, section)
          };
          
     };
     // Displaying the Navigation Bar
     navBar();
     //check if the section is in the viewPort
     function viewPort (element){
      const sectionPosition = element.getBoundingClientRect();
      return (sectionPosition.top>=0);
  }
    const your_active_class =document.querySelector('.your-active-class');
 // create a function to call all the below in the .addEventListener
  function checkForTheActvClass (){
      for (section of callSections){
         //if the section is in the viewPort
         if (viewPort(section)){
             //check if it isn't containg your-active-class
             if (!section.classList.contains('your-active-class')){
                  // Then add it ('your-active-class')
                  section.classList.add('your-active-class');
              }
          }
             else { 
                 //if it is not inside the viewPort then remove it ('your-active-class')
                 section.classList.remove('your-active-class');
          }
      }
  }
 // Using the .addEventListener in order to use the scroll action 
  document.addEventListener('scroll',checkForTheActvClass);