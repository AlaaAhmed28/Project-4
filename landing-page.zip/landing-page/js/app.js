//Defining the variables
const callSections = document.getElementsByTagName('section');
// Calling the ul element form the HTML
const unorderedList = document.getElementsByTagName('ul');
// Making the smooth scrolling 
function scrollSec(item, sec) {
  item.addEventListener('click', function (e) {
    e.preventDefault();
    sec.scrollIntoView({
      behavior: "smooth"
    })
  })
}
// Creating the navbar 
const navBar = function () {
  for (section of callSections) {
    let listItem = document.createElement("li");
    let text = document.createTextNode(section.dataset.nav);
    let anchor = document.createElement("a");
    let sectionID = section.getAttribute('id');
    anchor.href = `#${sectionID}`;
    anchor.className = "menu__link";
    anchor.appendChild(text);
    listItem.appendChild(anchor);
    unorderedList[0].appendChild(listItem);
    // calling the smooth scrolling function
    scrollSec(listItem, section)
  };

};
// Displaying the Navigation Bar
navBar();

// Using the  .hetBoundingClientRect() to retrieve the boundries of the section
function check(section) {
  return (section.getBoundingClientRect().top >= 0 && section.getBoundingClientRect().top <= 280);
}
//  See if the section in the viewport or not?  
const activeClass = function () {
  for (section of callSections) {
    if (check(section) == window.pageXOffset) {
      section.classList.remove('your-active-class');
    } else {
      section.classList.add('your-active-class');
    }
  }
};
const navItem = document.querySelector('#navbar__list');
const activeNavItems = function () {
  for (section of callSections) {
    if (check(section) == window.pageXOffset) {
      navItem.classList.remove('navbar__menu');
    } else {
      navItem.classList.add('navbar__menu');
    }
  }
};
// Using addEventListener to enable the scrolling event so that while scrolling the section get highlighted
document.addEventListener('scroll', activeClass);
document.addEventListener('scroll', activeNavItems);