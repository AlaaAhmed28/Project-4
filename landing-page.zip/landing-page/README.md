# Project Description
It's about to make a **landing page** not any one but it has to contain a *Navigation Bar* not a normal one . It has to be **DYNAMIC**. And also they want  it when you click on any section the page should  move to the section you **Clicked On** . Last but not least, they want a **smooth scrolling**

# Instructions 
I want to tell you nothing is *easy*. You have to take your time to fully understand everything and never leave a thing without understanding it. You also have to have a *Special Thing* which is ***Patiency***.

# Information about the author :
Name: ***Alaa Ahmed El Bardissi***
Age : *20 years old*
Major: Business Technologys